package Role;

import connectivity.ConnectionClass;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

import java.awt.*;
import java.io.IOException;
import java.sql.*;
import java.time.LocalDate;

public class roleOptions {
    @FXML private TextField roleID;

    public void alertMsg(String Message){
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setHeaderText(null);
        alert.setContentText(Message);
        alert.showAndWait();
    }
    public void infoMsg(String Message){
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setHeaderText(null);
        alert.setContentText(Message);
        alert.showAndWait();
    }
    public void loadWindow(String location, String title) throws IOException {
        Parent root= FXMLLoader.load(getClass().getResource(location));
        Scene scene= new Scene(root);
        Stage stage= new Stage(StageStyle.DECORATED);
        stage.setScene(scene);
        stage.setTitle(title);
        stage.show();
    }
    @FXML private Button up_role;
    @FXML private TextField search;
    @FXML private javafx.scene.control.TextField role_id;
    @FXML private javafx.scene.control.TextField role_name;
    @FXML private javafx.scene.control.TextField role_id1;
    @FXML private TextField role_emp;
    @FXML private javafx.scene.control.TextField role_hrs;
    @FXML private javafx.scene.control.TextField calc;


    public void mainpage1(ActionEvent event) throws IOException {
        Stage primaryStage = new Stage();
        Parent root = FXMLLoader.load(getClass().getResource("../Role/role.fxml"));
        Scene scene = new Scene(root,1188,851);
        scene.getStylesheets().add(getClass().getResource("../Owner/main.css").toExternalForm());
        primaryStage.setTitle("Innovative - e | Role ");
        primaryStage.setScene(scene);
        primaryStage.show();

    }
    public void addRole(ActionEvent event)  {
        ConnectionClass connectionClass = new ConnectionClass();
        Connection connection = connectionClass.getConnection();

        String sql = "INSERT INTO role (`roleID`, `roleName`,`employeeID`,`employeeName`,`empHours`,`CalculateHourlyPay`) VALUES ('"
                + role_id.getText() + "', '" + role_name.getText() + "', '"+ role_id1.getText() + "', '"+ role_emp.getText()+ "', '"+ role_hrs.getText() + "', '"+ calc.getText()+"');";

        PreparedStatement ps = null;
        try {
            ps = connection.prepareStatement(sql);
            infoMsg("Successfully Added Role");
        } catch (SQLException e) {
            e.printStackTrace();
        }
        try {
             ps.executeUpdate(sql);
        } catch (SQLException e) {
            alertMsg("Foreign Key Constrainst Input Wrong | Enter the Correct ID's for Employee ID ");

        }
    }
    public void deleteRole(ActionEvent event){
        ConnectionClass connectionClass = new ConnectionClass();
        Connection connection = connectionClass.getConnection();

        Statement statement = null;
        try {
            statement = connection.createStatement();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        String sql = "DELETE FROM role WHERE roleID = "+roleID.getText();
        try {
            statement.executeUpdate(sql);
            infoMsg("Successfully Deleted Role");
        } catch (SQLException e) {
            alertMsg("role ID not in Database | Please Input The correct ID");

        }
    }

    public void calculatePay(ActionEvent event){
        String role = role_name.getText();
        String hours = role_hrs.getText();

        if(role.equalsIgnoreCase("")&& hours.equalsIgnoreCase("")){
            alertMsg("Fields Cant Be Kept Empty");
        }

        if(role.equalsIgnoreCase("Hardware Technician")){
            double fee = Integer.parseInt(hours)*450;
            calc.setText(String.valueOf(fee));
            infoMsg("The associated Hourly pay for "+role_emp.getText()+"for doing the role as Hardware Technician is " + fee);
        }
        else if(role.equalsIgnoreCase("Programmer")){
            double fee = Integer.parseInt(hours)*500;
            calc.setText(String.valueOf(fee));
            infoMsg("The associated Hourly pay for "+role_emp.getText()+"for doing the role as Programmer is " + fee);
        }
        else if(role.equalsIgnoreCase("Software Installer")){
            double fee = Integer.parseInt(hours)*600;
            calc.setText(String.valueOf(fee));
            infoMsg("The associated Hourly pay for "+role_emp.getText()+" for doing the role as a Software Installer is " + fee);
        }
        else{
            alertMsg("Wrong Info Given");
        }
    }
    public void searchRole(ActionEvent event) throws SQLException {
        ConnectionClass connectionClass = new ConnectionClass();
        Connection connection = connectionClass.getConnection();
        ResultSet rs = connection.createStatement().executeQuery("SELECT * FROM role WHERE roleID = "+search.getText());

        String ID = "roleID";
        String name = "roleName";
        String empID = "employeeID";
        String empName = "employeeName";
        String empHours = "empHours";
        String pay = "CalculateHourlyPay";


        try{
            if (rs.next()){
                role_id.setText(rs.getString(ID));
                role_name.setText(rs.getString(name));
                role_id1.setText(rs.getString(empID));
                role_emp.setText(rs.getString(empName));
                role_hrs.setText(rs.getString(empHours));
                calc.setText(rs.getString(pay));


            }else{
                alertMsg("Inavalid ID Given");
            }
        }
        catch (Exception ex){
            ex.printStackTrace();
        }

    }
    public void updateRole(ActionEvent event){
        ConnectionClass connectionClass = new ConnectionClass();
        Connection connection = connectionClass.getConnection();

        Statement statement = null;
        try {
            statement = connection.createStatement();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        String sql = "UPDATE `role` SET `roleID`="+"'"+role_id.getText()+"'"+",`roleName`="+"'"+role_name.getText()+"'"+",`employeeID`="+"'"+role_id1.getText()+"'"+",`employeeName`="+"'"+role_emp.getText()+"'"+",`empHours`="+"'"+role_hrs.getText()+"'"+",`CalculateHourlyPay`="+"'"+calc.getText()+"'"+" WHERE roleID = "+search.getText();
        try {
            statement.executeUpdate(sql);
            infoMsg("Successfully Updated Role");
        } catch (SQLException e) {
            alertMsg("Foreign Key Constraints");

        }
    }
    public void calculatePay1(ActionEvent event){
        String role = role_name.getText();
        String hours = role_hrs.getText();

        if(role.equalsIgnoreCase("")&& hours.equalsIgnoreCase("")){
            alertMsg("Fields Cant Be Kept Empty");
        }

        if(role.equalsIgnoreCase("Hardware Technician")){
            double fee = Integer.parseInt(hours)*450;
            calc.setText(String.valueOf(fee));
        }
        else if(role.equalsIgnoreCase("Programmer")){
            double fee = Integer.parseInt(hours)*500;
            calc.setText(String.valueOf(fee));
        }
        else if(role.equalsIgnoreCase("Software Installer")){
            double fee = Integer.parseInt(hours)*600;
            calc.setText(String.valueOf(fee));
        }
        else{
            alertMsg("Wrong Info Given ");
        }
    }


}


